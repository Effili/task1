public class Test2 {
    public static void main(String[] args){
      Rectangle P2 = new Rectangle();{
      P2.setX1(0);
      P2.setY1(6);
      P2.setX2(5); 
      P2.setY2(9);
      
       boolean koor= true; {
			 if (P2.getX1()<0) {
				 koor = false;
				 }
			 if (P2.getX2()<0) {
				 koor = false;
				 }
			 if (P2.getY1()<0) {
				 koor = false;
				 }
			 if (P2.getY2()<0) {
				 koor = false;
				 }
			 System.out.println("лежат ли координаты в первом квадранте: " + koor);
			 }
      
      int A1=P2.Rect_print(); //координаты точек
     
  	  int A2=P2.move();
	  
	    int A3=P2.Dlina();
	  System.out.println("длина = " + A3);
	  
	  	int A4=P2.Shirina();
	  System.out.println("ширина = " + A4);
	  
	    boolean A5=P2.Kvadrat();
	  System.out.println("определение квадрата: " + A5);
	  
	    int A6=P2.Perimetr();
	  System.out.println("периметр = " + A6);
	  
	    int A7=P2.Ploshad();
	  System.out.println("площадь = " + A7+ "\n\n");
	  }
    }
}