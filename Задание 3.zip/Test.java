public class Test {
    public static void main(String[] args) {
      Rectangle P3 = new Rectangle();{
      P3.setX1(-5);
      P3.setY1(-7);
      P3.setX2(-8); 
      P3.setY2(-11);
      
      boolean koor= true; {
			 if (P3.getX1()<0) {
				 koor = false;
				 }
			 if (P3.getX2()<0) {
				 koor = false;
				 }
			 if (P3.getY1()<0) {
				 koor = false;
				 }
			 if (P3.getY2()<0) {
				 koor = false;
				 }
			 System.out.println("лежат ли координаты в первом квадранте: " + koor);
			 }
     
     int Z1=P3.Rect_print(); //координаты точек
     
  	 int Z2=P3.move();
	  
	   int Z3=P3.Dlina();
	  System.out.println("длина = " + Z3);
	  
	   int Z4=P3.Shirina();
	  System.out.println("ширина = " + Z4);
	  
	   boolean Z5=P3.Kvadrat();
	  System.out.println("определение квадрата: " + Z5);
	  
	   int Z6=P3.Perimetr();
	  System.out.println("периметр = " + Z6);
	  
	   int Z7=P3.Ploshad();
	  System.out.println("площадь = " + Z7);
    }
    }
}