public class Test3 {
    public static void main(String[] args) {
        Rectangle P1 = new Rectangle();{
        P1.setX1(2);
        P1.setY1(4);
        P1.setX2(5); 
        P1.setY2(7);
       
        boolean koor= true; {
			 if (P1.getX1()<0) {
				 koor = false;
				 }
			 if (P1.getX2()<0) {
				 koor = false;
				 }
			 if (P1.getY1()<0) {
				 koor = false;
				 }
			 if (P1.getY2()<0) {
				 koor = false;
				 }
			 System.out.println("лежат ли координаты в первом квадранте: " + koor);
			 }
         
        
        int S1=P1.Rect_print(); //координаты точек
       
    	  int S2=P1.move(); // смещение по осям
  	 
  	    int S3=P1.Dlina();
  	  System.out.println("длина = " + S3);
  	  
  	  	int S4=P1.Shirina();
	  System.out.println("ширина = " + S4);
	  
	 	    boolean S5=P1.Kvadrat();
	  System.out.println("определение квадрата: " + S5);
	  
	      int S6=P1.Perimetr();
	  System.out.println("периметр = " + S6);
	  
	      int S7=P1.Ploshad();
	  System.out.println("площадь = " + S7 +"\n\n");
        }
    }
}