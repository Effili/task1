import java.util.Scanner;
class Rectangle{
	
	private int x1, y1, x2, y2;

	private int d, c, p, s;
	boolean k;
	
	public Rectangle (int x1, int y1, int x2, int y2){
	
	this.x1=x1;
	this.y1=y1;
	this.x2=x2;
	this.x2=x2;
	}
		
	void setX1(int x1) {
		this.x1=x1;
	}
	int getX1() {
		return x1;
	}
	
	void setY1(int y1) {
		this.y1=y1;
	}
	int getY1() {
		return y1;
	}
	void setX2(int x2) {
		this.x2=x2;
	}
	int getX2() {
		return x2;
	}
	void setY2(int y2) {
		this.y2=y2;
	}
	int getY2() {
		return y2;
	}
	
	public Rectangle(int height, int width) {
    this.x1 = 0;
    this.y1 = 0;
	this.x2 = width;
	this.y2 = height;
	}
	
	 public Rectangle() {
	 this.x1 = 0;
	 this.x2 = 0;
	 this.y1 = 0;
	 this.y2 = 0;
	 }
	 
	 	 
	 
	 public int Rect_print() {
	System.out.println("координата первой точки, где х1=" + x1 + ", а y1=" + y1+"\nкоординаты второй точки, где х2=" + x2 +", а у2=" + y2);
			 	
	 	this.x1=x1;
		this.y1=y1;
		this.x2=x2;
		this.x2=x2;
		return 0; 
	 }
	 
	    public int move () {
	    	Scanner input = new Scanner (System.in);
	    	System.out.println("введите значение dx: ");
	    	int dx = input.nextInt();
	        System.out.println("введите значение dy: ");
	        int dy = input.nextInt();
	    		       
	        System.out.println("координаты первой точки со сдвигом, где x1= " + (x1+dx) + ", а y1= " + (y1+dy));
	        System.out.println("координаты первой точки со сдвигом, где x2= " + (dx+x2)+ ", а y2= " + (dy+y2));
	        
	        return 0;
	    }
	    public int Dlina () { // длина
	    	if (x1>x2) {
	    		Math.abs(this.d=x1-x2);
	    	}
	    	else {	    	
	    	this.d=x2-x1;}
	    	return d;
	    }
	    	
	    	  public int Shirina () { // ширина
	  	    	if (y1>y2) {
	  	    		Math.abs(this.c=y1-y2);
	  	    	}
	  	    	else {	    	
	  	    	this.c=y2-y1;}
	  	    	return c;
	    	  }
	    	  
	    	  public boolean Kvadrat () { // проверка на квадрат
		  	    	if (x2-x1==y2-y1) {
		  	    		k=true;
		  	    	}
		  	    	return k;
		    	  }
	    	  
	    	  public int Perimetr () { // периметр
		  	    	p=(Math.abs(x2-x1)+Math.abs(y2-y1))*2;
		  	    	return p;
		    	  }  
	    	  public int Ploshad () { // площадь
		  	    	s=(x2-x1)*(y2-y1);
		  	    	return Math.abs(s);
		    	  }  
	    	  
	    	  
	}