class Test {
		
				private static int[] x = new int[] { 4, 9, 3, 2, 5, 18, 21, 7, 11, 15, 5, 17 };
		 
			public int [] getx() {
				return x;
			}
			public void setx(int[] x) {
				this.x=x;
			}
			
			
			int y = x[0];
			int z = x[0];	
			
			int  getMax() { // максимальное значение
			for (int i = 0; i<x.length; i++) {
	    	if (x[i]>y) 
	    	y=(x[i]);
			}
	    	return y;
			}
			
			
			
	   int getMix() { // минимальное значение
		   for (int i = 0; i<x.length; i++) {
		   	if (x[i]<z) 
		   	z=(x[i]);
		    }
		    return z;
		    }
	      	
			   
	   	int [] f = x; 
	   	 	
	   	int[] sortArr() { // сортировка по возрастанию
		for (int i = 0; i < x.length; i++) {
		    int cMin = x[i];
		    int cMinIndex = i;
		    	for (int j = i + 1; j < x.length; j++) {
		   if (cMin > x[j]) {
		     cMin = x[j];
		     cMinIndex = j;
		        }
		      }
		      if (cMinIndex != i) {
		      x[cMinIndex] = x[i];
		      x[i] = cMin;
		        
		    f[i]=x[i];
		      }    
		}
		    return f;	
				
	    }
	   	
		int [] r = x;
	    		
		int [] sortReserv() { // сортировка по убыванию
			for (int i = 0; i < x.length; i++) {
			    int rMax = x[i];
			    int rMaxIndex = i;
			   	   for (int j = i + 1; j < x.length; j++) {
			     if (rMax < x[j]) {
			     rMax = x[j];
			     rMaxIndex = j;
			        }
			      }
			         if (rMaxIndex != i) {
			         x[rMaxIndex] = x[i];
			         x[i] = rMax;
			      }
			        r[i]=x[i];
			}
			     return r;	
				
		}
	}
