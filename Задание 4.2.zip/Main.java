public class Main{
	    public static void main(String[] args) {
	
	    	
	    	Test P = new Test();
	    	int Y = P.getMax();
	    	System.out.println("максимальное значение = " + Y);
	    	
	    	int Z = P.getMix();
	    	System.out.println("минимальное значение = " + Z);
	    	
	    	int f [] = P.sortArr();
	    	System.out.print("сортировка по возрастанию: ");
	    	for (int F:f) {
	    	System.out.print(F+ " ");
}
	    		    	
	    	int r [] = P.sortReserv();
	    	System.out.print("\nсортировка по убыванию: ");
	    	for (int R:r) {
	    	System.out.print(R+ " ");
}
	    	
}
}