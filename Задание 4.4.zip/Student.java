import java.util.ArrayList;
import java.util.Scanner;

	public class Student{

	static ArrayList<Integer> array = new  ArrayList <Integer> ();
	 	
		public static ArrayList<Integer> sm(){  //  4.1
			 Scanner input = new Scanner(System.in);{
				System.out.println("Введите значения: ");{
					for(int i=0; i<5; i++) {
					int value = (int) input.nextDouble();
					array.add(value);
				}
			 }
		}
			return array;
	}
		public static int sum(){  //  4.2
		int sum = 0;{
			for(int i = 0; i<array.size(); i++){
				sum += array.get(i);
	 }			
  }		
		return sum;
	}
		
		public static ArrayList<Integer> sor(){ // 4.3
		ArrayList<Integer>sort = array ;
		
			 for(int i = 0; i<sort.size(); i++){
				 for (int j = sort.size() - 1; j > i; j--) {
		              if (sort.get(i) > sort.get(j)) {

		                  int znc = sort.get(i);
		                  sort.set(i,sort.get(j)) ;
		                  sort.set(j, znc);
				
			 }			
		   }
		}
	
		return sort;
	}
	}