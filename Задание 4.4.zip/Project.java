import java.util.ArrayList;
public class Project {

	public static void main(String[] args) {
				
		
		ArrayList<Integer> amax = Student.sm();{
		for (Integer a: amax) System.out.print(a + " ");
		}
		
		
		int max = Student.sum();{
			System.out.println("\nсумма: " + max);
		}		
			
		System.out.print("сортировка: ");
		ArrayList<Integer> Sort = Student.sor();{
			for (Integer b: Sort) System.out.print(b + " ");
	
	}
	}
}
	